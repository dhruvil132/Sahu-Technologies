<?php

    session_start();
    extract($_POST);
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];
    $message = $_POST["message"];
    

    $conn = new mysqli('127.0.0.1', 'root', '', 'sahu');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $stmt = $conn->prepare("INSERT INTO register (fname, lname, mobile, email, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $fname, $lname, $mobile, $email, $message);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    

    header("Location: contact_us.html")
?>